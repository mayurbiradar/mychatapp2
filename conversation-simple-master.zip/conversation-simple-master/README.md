This Node.js app demonstrates the Conversation service in a simple chat interface.
developed for the TCS Waston training.
